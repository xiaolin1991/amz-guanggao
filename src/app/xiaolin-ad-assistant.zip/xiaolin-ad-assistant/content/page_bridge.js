/**
 * 晓林广告助手 - 页面主环境桥接引擎 (Main World Bridge v1.7.0)
 * 运行于页面 MAIN World，直接访问 React 17/18 的 _valueTracker 与 __reactProps$，
 * 针对亚马逊 ucmSpApp / sc-storm-ui / ag-grid 竞价弹窗完成真实的：
 * 【唤醒弹窗 -> 填入竞价 -> 触发 React 状态 -> 点击黑色“保存”按钮发布】全流程
 */
(function () {
  if (window.__XL_MAIN_BRIDGE_READY__) return;
  window.__XL_MAIN_BRIDGE_READY__ = true;

  /**
   * 在页面主环境 (Main World) 中向 React 受控 <input type="number"> 注入新竞价并触发 React 内部状态同步
   */
  function setReactInputValueInMainWorld(inputEl, newValueStr) {
    if (!inputEl) return false;
    try {
      inputEl.focus({ preventScroll: true });
    } catch (e) {
      try { inputEl.focus(); } catch (e2) {}
    }

    const oldVal = inputEl.value;

    // 1. 获取主环境原生 HTMLInputElement value setter
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeSetter) {
      nativeSetter.call(inputEl, newValueStr);
    } else {
      inputEl.value = newValueStr;
    }

    // 2. 关键：在主环境中重置 React 的 _valueTracker，让 React 100% 识别到 oldVal -> newValueStr 的变更！
    const tracker = inputEl._valueTracker;
    if (tracker && typeof tracker.setValue === 'function') {
      try {
        tracker.setValue(oldVal);
      } catch (e) {}
    }

    // 3. 派发完整主环境原生事件链，唤醒 sc-storm-ui / React 受控组件
    inputEl.dispatchEvent(new Event('focus', { bubbles: true }));
    try {
      inputEl.dispatchEvent(new InputEvent('beforeinput', {
        bubbles: true,
        cancelable: true,
        data: String(newValueStr),
        inputType: 'insertText'
      }));
      inputEl.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        cancelable: true,
        data: String(newValueStr),
        inputType: 'insertText'
      }));
    } catch (e) {
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    }
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    inputEl.dispatchEvent(new KeyboardEvent('keyup', {
      key: String(newValueStr).slice(-1) || '0',
      bubbles: true,
      cancelable: true
    }));

    // 4. 双重保障：若节点上挂载了 __reactProps$，检查并确保 React 感知最新值
    try {
      const reactKey = Object.keys(inputEl).find(k => k.startsWith('__reactProps$') || k.startsWith('__reactEventHandlers$'));
      if (reactKey && inputEl[reactKey] && typeof inputEl[reactKey].onChange === 'function') {
        // 原生 input 事件在重置 _valueTracker 后已被 React 捕获；此处保持焦点等待点击保存
      }
    } catch (e) {}

    return true;
  }

  /**
   * 从弹出的竞价输入框向上回溯 1~8 层，精准定位 sc-storm-ui 弹窗容器内的黑色【保存】按钮
   * 对应真实 DOM 结构：
   * <input data-e2e-id="ucmSpApp:spAdGroupTargets:cell-bid:input" ...>
   * 向上 4~5 层的兄弟节点 <div class="sc-storm-ui-..."><button>取消</button><button>保存</button></div>
   */
  function findStormUiPopoverSaveButton(inputEl) {
    if (!inputEl) return null;

    const isSaveButton = (btn, allowPrimaryFallback = false) => {
      if (!btn || btn.disabled || btn.getAttribute('aria-disabled') === 'true') return false;
      if (btn.closest('#xl-floating-panel, #xl-floating-launcher, #xl-global-badge-tooltip')) return false;
      const r = btn.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return false;

      // 严禁误点表格行内“建议竞价”列的【应用】按钮或竞价列自身的【编辑】触发按钮
      const e2e = (btn.getAttribute('data-e2e-id') || '') + ' ' + (btn.getAttribute('data-takt-id') || '');
      if (e2e.includes('cell-bid:edit')) return false;
      const inGridRow = btn.closest('[role="row"], tr, .ag-row');
      const txt = (btn.textContent || '').replace(/\s+/g, '').trim();
      const lowerTxt = txt.toLowerCase();
      if (inGridRow && (txt === '应用' || lowerTxt === 'apply')) return false;

      // 严禁点击取消或关闭按钮
      const aria = ((btn.getAttribute('aria-label') || '') + ' ' + (btn.getAttribute('title') || '')).toLowerCase();
      if (txt === '取消' || lowerTxt === 'cancel' || txt === '关闭' || lowerTxt === 'close' || txt === '✕' || txt === '×') return false;
      if (aria.includes('取消') || aria.includes('cancel') || aria.includes('close')) return false;

      // 精确匹配亚马逊弹窗的【保存】/【保存更改】/【Save】按钮
      if (txt === '保存' || txt === '保存更改' || lowerTxt === 'save' || lowerTxt === 'savechanges' ||
          txt === '确定' || txt === '确认' || lowerTxt === 'ok' || txt === '✓' || txt === '✔' ||
          e2e.includes('save') || e2e.includes('confirm') || e2e.includes('submit') ||
          btn.getAttribute('type') === 'submit') {
        return true;
      }

      // 在局部 Popover 内部，如果只有“取消”和另一个带 SVG 或主样式的按钮
      if (allowPrimaryFallback) {
        if (btn.querySelector('svg') && !aria.includes('cancel') && !aria.includes('close')) return true;
      }
      return false;
    };

    // 1. 从 inputEl 逐层向上查找（最多 8 层，直到遇到包含按钮组的 Popover 根节点）
    let curr = inputEl.parentElement;
    let depth = 0;
    while (curr && curr !== document.body && depth < 8) {
      // 不要跨入整个表格根节点
      if (curr.classList.contains('ag-root') || curr.getAttribute('role') === 'grid') break;
      const btns = Array.from(curr.querySelectorAll('button, [role="button"], input[type="submit"]'));
      if (btns.length > 0) {
        const exact = btns.find(b => isSaveButton(b, false));
        if (exact) return exact;
        const fallback = btns.find(b => isSaveButton(b, true));
        if (fallback) return fallback;
      }
      curr = curr.parentElement;
      depth++;
    }

    // 2. 在整个 document.body 中查找距离 inputEl 视觉坐标 280px 以内的【保存 / 保存更改】按钮
    const iRect = inputEl.getBoundingClientRect();
    const icx = iRect.left + iRect.width / 2;
    const icy = iRect.top + iRect.height / 2;
    const allBtns = Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"]'));
    const nearby = allBtns.find(b => {
      if (!isSaveButton(b, false)) return false;
      const r = b.getBoundingClientRect();
      const dist = Math.hypot((r.left + r.width / 2) - icx, (r.top + r.height / 2) - icy);
      return dist <= 320;
    });
    return nearby || null;
  }

  /**
   * 触发主环境真实按钮点击序列
   */
  function triggerMainWorldClick(el) {
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(evtName => {
      el.dispatchEvent(new MouseEvent(evtName, {
        view: window,
        bubbles: true,
        cancelable: true,
        clientX: cx,
        clientY: cy,
        buttons: 1
      }));
    });
    if (typeof el.click === 'function') {
      el.click();
    } else {
      el.dispatchEvent(new MouseEvent('click', {
        view: window,
        bubbles: true,
        cancelable: true,
        clientX: cx,
        clientY: cy,
        buttons: 1
      }));
    }
  }

  /**
   * 监听来自 Content Script 的改价指令，在页面主环境执行完整改价与保存
   */
  window.addEventListener('xl-main-world-apply-bid', (event) => {
    const detail = event.detail || {};
    const { reqId, bidValue } = detail;
    const valStr = typeof bidValue === 'number' ? bidValue.toFixed(2) : parseFloat(bidValue).toFixed(2);

    const finish = (success, reason) => {
      window.dispatchEvent(new CustomEvent('xl-main-world-bid-result', {
        detail: { reqId, success, reason, bidValue: valStr }
      }));
    };

    // 1. 如果当前页面已经打开了批量改价弹窗 (ucmSpApp:spAdGroupTargets:bulkAction:defaultBidAction:input)
    const bulkInput = document.querySelector(
      'input[data-e2e-id*="bulkAction:defaultBidAction:input"], input[data-takt-id*="bulkAction:defaultBidAction:input"], input[id*="bulkAction:defaultBidAction:input"]'
    );
    if (bulkInput && bulkInput.getBoundingClientRect().width > 0) {
      setReactInputValueInMainWorld(bulkInput, valStr);
      setTimeout(() => {
        const saveBulkBtn = findStormUiPopoverSaveButton(bulkInput);
        if (saveBulkBtn) triggerMainWorldClick(saveBulkBtn);
        finish(true, 'bulk_modal_saved');
      }, 100);
      return;
    }

    // 2. 定位 Content Script 标记的目标竞价单元格 [data-xl-active-bid-target="true"]
    const bidCell = document.querySelector('[data-xl-active-bid-target="true"]');
    if (!bidCell) {
      finish(false, 'no_bid_cell');
      return;
    }

    // 3. 在竞价单元格内精确查找亚马逊真实竞价编辑按钮：
    // <button data-e2e-id="ucmSpApp:spAdGroupTargets:cell-bid:edit" data-takt-id="ucmSpApp:spAdGroupTargets:cell-bid:edit" data-testid="ucmSpApp:spAdGroupTargets:cell-bid-0:edit" ...>
    const editBtn = bidCell.querySelector(
      'button[data-e2e-id*="cell-bid:edit"], button[data-takt-id*="cell-bid:edit"], button[data-testid*="cell-bid"], button[aria-haspopup="true"], button'
    ) || bidCell.querySelector('.cell-renderer-main-content')?.closest('button') ||
         bidCell.querySelector('[role="button"], .bid-trigger') || bidCell;

    // 提取当前行的精确 testid 前缀（如 "ucmSpApp:spAdGroupTargets:cell-bid-0:"），用于 100% 锁定对应弹窗 input
    const btnTestId = editBtn.getAttribute('data-testid') || '';
    const expectedInputId = btnTestId.includes(':edit') ? btnTestId.replace(':edit', ':input') : '';

    const findTargetPopoverInput = () => {
      // A. 若有精确对应的 id="ucmSpApp:spAdGroupTargets:cell-bid-0:input"
      if (expectedInputId) {
        const exactById = document.getElementById(expectedInputId);
        if (exactById && exactById.getBoundingClientRect().width > 0) return exactById;
      }
      // B. 匹配亚马逊竞价弹窗专属属性 data-e2e-id="ucmSpApp:spAdGroupTargets:cell-bid:input"
      const e2eInputs = Array.from(document.querySelectorAll(
        'input[data-e2e-id*="cell-bid:input"], input[data-takt-id*="cell-bid:input"], input[id*="cell-bid"][id*=":input"]'
      )).filter(inp => inp.getBoundingClientRect().width > 0);
      if (e2eInputs.length > 0) return e2eInputs[e2eInputs.length - 1];

      // C. 兼容沙盒与通用弹窗：查找 bidCell 内部或距离 bidCell 280px 以内的可见数值输入框
      const cellInp = bidCell.querySelector('input:not([type="checkbox"]):not([type="hidden"])');
      if (cellInp && cellInp.getBoundingClientRect().width > 0) return cellInp;

      const cRect = bidCell.getBoundingClientRect();
      const ccx = cRect.left + cRect.width / 2;
      const ccy = cRect.top + cRect.height / 2;
      const allInps = Array.from(document.querySelectorAll('input[type="number"], input[type="text"], input[inputmode="decimal"]'))
        .filter(inp => {
          if (inp.closest('#xl-floating-panel, #xl-floating-launcher')) return false;
          const ph = (inp.getAttribute('placeholder') || '').toLowerCase();
          if (ph.includes('找到') || ph.includes('搜索') || ph.includes('search') || ph.includes('find')) return false;
          const r = inp.getBoundingClientRect();
          if (r.width <= 4 || r.height <= 4) return false;
          const dist = Math.hypot((r.left + r.width / 2) - ccx, (r.top + r.height / 2) - ccy);
          return dist <= 320;
        });
      return allInps[0] || null;
    };

    // 如果弹窗尚未打开，点击 editBtn 唤醒弹窗
    let popInput = findTargetPopoverInput();
    if (!popInput) {
      triggerMainWorldClick(editBtn);
    }

    // 轮询等待弹窗 <input> 挂载完成
    const pollTimes = [40, 100, 180, 280, 420];
    let handled = false;

    pollTimes.forEach((delay, idx) => {
      setTimeout(() => {
        if (handled) return;
        const inp = findTargetPopoverInput();
        if (inp) {
          handled = true;
          // 写入新竞价并同步主环境 React _valueTracker
          setReactInputValueInMainWorld(inp, valStr);

          // 等待 70ms 与 170ms 让 React 更新按钮状态后，点击黑色【保存】按钮
          setTimeout(() => {
            const saveBtn = findStormUiPopoverSaveButton(inp);
            if (saveBtn) {
              triggerMainWorldClick(saveBtn);
            } else {
              ['keydown', 'keypress', 'keyup'].forEach(kEvt => {
                inp.dispatchEvent(new KeyboardEvent(kEvt, {
                  key: 'Enter',
                  code: 'Enter',
                  keyCode: 13,
                  which: 13,
                  bubbles: true,
                  cancelable: true
                }));
              });
            }
          }, 75);

          setTimeout(() => {
            // 若 180ms 后弹窗仍未关闭，补点一次【保存】按钮确保提交
            if (document.body.contains(inp) && inp.getBoundingClientRect().width > 0) {
              const saveBtn2 = findStormUiPopoverSaveButton(inp);
              if (saveBtn2) {
                triggerMainWorldClick(saveBtn2);
              } else {
                inp.dispatchEvent(new Event('change', { bubbles: true }));
                inp.blur();
              }
            }
            bidCell.style.transition = 'outline 0.2s ease, background-color 0.2s ease';
            bidCell.style.outline = '2px solid #10b981';
            bidCell.style.backgroundColor = 'rgba(16, 185, 129, 0.12)';
            finish(true, 'popover_saved');
          }, 190);
        } else if (idx === 1) {
          // 若第 100ms 仍未弹出，尝试点击按钮内部的 .cell-renderer-main-content
          const innerSpan = editBtn.querySelector('.cell-renderer-content-text, .cell-renderer-main-content');
          if (innerSpan) triggerMainWorldClick(innerSpan);
        } else if (idx === pollTimes.length - 1) {
          finish(false, 'input_not_opened');
        }
      }, delay);
    });
  });
})();
